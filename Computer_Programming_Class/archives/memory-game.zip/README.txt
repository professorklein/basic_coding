A Pen created at CodePen.io. You can find this one at https://codepen.io/natewiley/pen/HBrbL.

 A JavaScript memory game on Codepen !
Click the cards and find matches to win.. you know how to play.
Hope you like it :)
